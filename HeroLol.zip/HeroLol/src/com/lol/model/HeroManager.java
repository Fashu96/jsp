package com.lol.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;

public class HeroManager {

	
	private Hero hero;
	private List<Hero> heroes;
	//����jdbc
	private Connection conn;
	private Statement stmt;
	private ResultSet rs;
	private PreparedStatement ps;
	//���ݿ�����
	public Connection getConnetion(){
		String driverName="com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url="jdbc:sqlserver://localhost:1433;DatabaseName=jsp��Ŀ��ҵ";
		String user="sa";
		String password="19961010";
		try{
			Class.forName(driverName);
			return DriverManager.getConnection(url, user, password);
		}catch(ClassNotFoundException | SQLException e){
			e.printStackTrace();
			return null;
		}
	}
	public HeroManager(){
		
	}
	
	public Hero findOne(int id){
		conn=getConnetion();
		try{
			stmt=conn.createStatement();
			rs=stmt.executeQuery("select * from hero where id="+id);
			hero=new Hero();
			while(rs.next()){
				hero.setName(rs.getString("name"));
				hero.setNickName(rs.getString("nick_name"));
				hero.setImage(rs.getString("image"));
				hero.setAvatar(rs.getString("avatar"));
				hero.setDesc(rs.getString("description"));
			}
			rs.close();
			stmt.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return hero;
	}
	/**
	 * ��������Ӣ��
	 */
	public List<Hero> findAll(){
		conn=getConnetion();
		try{
			stmt=conn.createStatement();
			rs=stmt.executeQuery("select *from hero");
			heroes=new ArrayList<>();
		}catch(SQLException e){
			e.printStackTrace();
		}
		return heroes;
	}
	public void add(Hero hero){
		String sql="insert into hero (name,nick_name,image,avatar,description) values(?,?,?,?,?)";
	conn=getConnetion();
	try{
		//Ԥ����
		ps=conn.prepareStatement(sql);
		//��ֻ������hero��ȡ������
		ps.setString(1, hero.getName());
		ps.setString(2, hero.getNickName());
		ps.setString(3, hero.getAvatar());
		ps.setString(4, hero.getImage());
		ps.setString(5, hero.getDesc());
		ps.executeUpdate();
		
		ps.close();
		conn.close();
	}catch(SQLException e){
		e.printStackTrace();
	}
	}
	public void modify(Hero hero){
		String sql="insert into hero (name,nick_name,image,avatar,description) values(?,?,?,?,?)";
	conn=getConnetion();
	try{
		//Ԥ����
		ps=conn.prepareStatement(sql);
		//��ֵ������hero��ȡ������
		ps.setString(1, hero.getName());
		ps.setString(2, hero.getNickName());
		ps.setString(3, hero.getAvatar());
		ps.setString(4, hero.getImage());
		ps.setString(5, hero.getDesc());
		ps.executeUpdate();
		
		ps.close();
		conn.close();
	}catch(SQLException e){
		e.printStackTrace();
	}
	}
}
